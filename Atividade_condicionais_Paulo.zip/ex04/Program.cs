﻿using System;

// VerificadorDeIntervalo

            Console.WriteLine("Digite um número: ");
            int numero = Convert.ToInt32(Console.ReadLine());

            if (numero >= 1 && numero <= 100)
            {
                Console.WriteLine("O número está dentro do intervalo de 1 a 100.");
            }
            else
            {
                Console.WriteLine("O número está fora do intervalo de 1 a 100.");
            }
    