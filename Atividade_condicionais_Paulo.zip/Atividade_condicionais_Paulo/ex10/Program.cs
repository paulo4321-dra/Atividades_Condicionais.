﻿
using System;

// calculadoradesconto

        {
            Console.WriteLine("digite o valor da compra: r$ ");
            double valorcompra = Double.Parse(Console.ReadLine());

            if (valorcompra > 100)
            {
                // aplica o desconto de 10%
                double desconto = valorcompra * 0.1;
                double valorfinal = valorcompra - desconto;

                Console.WriteLine("o valor final com desconto é: r$ " + valorfinal);
            }
            else
            {
                Console.WriteLine("o valor da compra é: r$ " + valorcompra);
            }
        }


