﻿using System;

// VerificarAprovacao

        {
            Console.WriteLine("Digite a nota do aluno: ");
            double nota = Convert.ToDouble(Console.ReadLine());

            if (nota >= 6)
            {
                Console.WriteLine("O aluno foi aprovado!");
            }
            else
            {
                Console.WriteLine("O aluno foi reprovado.");
            }
        }
  