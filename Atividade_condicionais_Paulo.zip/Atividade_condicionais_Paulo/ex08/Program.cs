﻿using System;
 
// VerificadorDeVoto

        {
            Console.WriteLine("Digite sua idade: ");
            int idade = int.Parse(Console.ReadLine());

            if (idade >= 16)
            {
                Console.WriteLine("Você tem idade para votar.");
            }
            else
            {
                Console.WriteLine("Você não tem idade para votar.");
            }
        }


