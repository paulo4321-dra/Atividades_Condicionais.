﻿using System;

// ClassificadorDeNotas

        {
            Console.WriteLine("Digite a nota do aluno (0 a 10): ");
            double nota = Convert.ToDouble(Console.ReadLine());

            if (nota >= 9)
            {
                Console.WriteLine("Excelente!");
            }
            else if (nota >= 7)
            {
                Console.WriteLine("Boa!");
            }
            else if (nota >= 5)
            {
                Console.WriteLine("Regular.");
            }
            else
            {
                Console.WriteLine("Baixa.");
            }
        }
  